/*
* Quintin B. Rozelle
* 10/10/2023
* 7-1 Project
*
* Code modified from files supplied by Professor Brian Battersby - SNHU Instructor / Computer Science
*/

#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "meshes.h"
#include <learnOpengl/camera.h>
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>
#include <vector>
#include <array>

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
	const char* const WINDOW_TITLE = "7-1 Project (Quintin B. Rozelle)"; // Macro for window title

	// Variables for window width and height
	const int WINDOW_WIDTH = 800;
	const int WINDOW_HEIGHT = 600;

	// Stores the GL data relative to a given mesh
	struct GLMesh
	{
		GLuint vao;         // Handle for the vertex array object
		GLuint vbos[2];     // Handles for the vertex buffer objects
		GLuint nIndices;    // Number of indices of the mesh
	};

	// Global variables
	// Main GLFW window
	GLFWwindow* gWindow = nullptr;

	// Shader programs
	GLuint objectShaderProgram;
	GLuint lightShaderProgram;

	//Shape Meshes from Professor Brian
	Meshes meshes;

	// Vector containing texture names
	std::vector<const char*> textureNames = {
		"RubixPyramid1.png",		//0
		"RubixPyramid2.png",		//1
		"RubixPyramid3.png",		//2
		"Counter.png",				//3
		"BlockTop.jpg",				//4
		"BlockLong1.jpg",			//5
		"BlockLong2.jpg",			//6
		"BlockShort1.png",			//7
		"BlockShort2.png",			//8
		"StudTop.png",				//9
		"Watermelon.png",			//10
		"Salt.png",					//11
		"CounterSpecular.png",		//12
		"StudSides.png",			//13
		"RubixPyramidSpecular.png"	//14
	};

	//vector containing texture IDs
	std::vector<GLuint> textureIDs(textureNames.size());

	// Camera variables
	Camera camera(glm::vec3(0.0f, 3.0f, 8.0f), glm::vec3(0.0f, 1.0f, 0.0f), -90.0f, -15.0f);
	float lastX = WINDOW_WIDTH / 2.0f;
	float lastY = WINDOW_HEIGHT / 2.0f;
	bool firstMouse = true;
	glm::mat4 view;
	glm::mat4 projection = glm::perspective(glm::radians(camera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
	
	// variables to save perspective view when switching from orthographic view
	glm::vec3 perspectivePosition;
	glm::vec3 perspectiveFront;
	glm::vec3 perspectiveUp;
	float perspectivePitch;
	float perspectiveYaw;

	// light values
	// direct light is meant to mimic sunlight coming through window
	// point lights are menat to mimic ceiling lights with a soft yellow color
	glm::vec3 lightPosition1 = glm::vec3(-10.0f, 5.0f, 3.0f);  // direct light
	glm::vec3 lightColor1 = glm::vec3(1.0f, 1.0f, 1.0f);  // white
	glm::vec3 lightPosition2 = glm::vec3(-4.0f, 10.0f, 0.0f);  // point light 1
	glm::vec3 lightColor2 = glm::vec3(0.99f, 0.92f, 0.75f);  // soft yellow
	glm::vec3 lightPosition3 = glm::vec3(10.0f, 10.0f, 0.0f);  // point light 2
	glm::vec3 lightColor3 = glm::vec3(0.99f, 0.92f, 0.75f);  // soft yellow

	// timing
	float deltaTime = 0.0f;
	float lastFrame = 0.0f;
	
	// global variable to store toggle status
	bool isWireframe = false;
	bool isOrtho = false;
	int orthoView = 0;
}

////////////////////////////////////////////////////////////////////////////////////////
// SHADER CODE
/* Object Vertex Shader Source Code*/
const GLchar* objectVertexShaderSource = GLSL(440,
	layout(location = 0) in vec3 vecCoords; // Vertex data from Vertex Attrib Pointer 0
	layout(location = 1) in vec3 vecNormal;  // Normal data from Vertex Attrib Pointer 1
	layout(location = 2) in vec2 vecTexture;  // Texture data from Vertex Attrib Pointer 2

	out vec3 vertexCoords; // variable to transfer coordinate data to the fragment shader
	out vec3 vertexNormal; // variable to transfer normal data to the fragment shader
	out vec2 vertexTexture;  // variable to transfer texture data to the fragment shader

	//Global variables for the  transform matrices
	uniform mat4 model;
	uniform mat4 view;
	uniform mat4 projection;
	uniform int textureCoordsMultiple;

	void main()
	{
		gl_Position = projection * view * model * vec4(vecCoords, 1.0f); // transforms vertices to clip coordinates

		vertexCoords = vec3(model * vec4(vecCoords, 1.0f));
		vertexNormal = mat3(transpose(inverse(model))) * vecNormal;
		vertexTexture = vecTexture * textureCoordsMultiple;
	}
);


/* Object Fragment Shader Source Code*/
const GLchar* objectFragmentShaderSource = GLSL(440,
	in vec3 vertexCoords;
	in vec3 vertexNormal;
	in vec2 vertexTexture;

	out vec4 fragmentColor;

	// material variables
	struct Material {
		sampler2D uTexture;
		sampler2D uSpecular;
		float shininess;
		int usesTexture;
		int usesSpecular;
		vec3 color;
	};

	// light variables
	struct PointLight {
		vec3 position;

		float constant;
		float linear;
		float quadratic;

		vec3 ambient;
		vec3 diffuse;
		vec3 specular;

		float intensity;
		vec3 color;
	};

	struct DirectLight {
		vec3 direction;

		vec3 ambient;
		vec3 diffuse;
		vec3 specular;

		float intensity;
		vec3 color;
	};

	uniform vec3 viewPosition;
	uniform Material material;
	uniform PointLight pointLight1;
	uniform PointLight pointLight2;
	uniform DirectLight directLight;

	vec3 CalcDirectLight(DirectLight light, vec3 normal, vec3 viewDir, vec3 objectFragColor, vec3 objectSpecularity);
	vec3 CalcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir, vec3 objectFragColor, vec3 objectSpecularity);

	void main()
	{
		// local variables
		vec3 objectFragColor;
		vec3 objectSpecularity;
		vec3 norm = normalize(vertexNormal);
		vec3 viewDir = normalize(viewPosition - vertexCoords);

		// Assign appropriate coloring based on usesTexture status.
		//    0 = Texture is not used. Assign color
		//    1 = Texture is used. Assign texture
		if (material.usesTexture == 1)
		{
			objectFragColor = vec3(texture(material.uTexture, vertexTexture));
		}
		else
		{
			objectFragColor = vec3(material.color);
		}

		// Assign appropriate specularity based on usesSpecular status.
		//    0 = Specular map is not used. Assign default of (1.0f, 1.0f, 1.0f)
		//    1 = Specular map is used. Assign specular map
		if (material.usesSpecular == 1)
		{
			objectSpecularity = vec3(texture(material.uSpecular, vertexTexture));
		}
		else
		{
			objectSpecularity = vec3(1.0f);
		}

		// Calculate contribution of each light source
		vec3 result = CalcDirectLight(directLight, norm, viewDir, objectFragColor, objectSpecularity);
		result += CalcPointLight(pointLight2, norm, vertexCoords, viewDir, objectFragColor, objectSpecularity);
		result += CalcPointLight(pointLight1, norm, vertexCoords, viewDir, objectFragColor, objectSpecularity);

		fragmentColor = vec4(result, 1.0);
	}

	vec3 CalcDirectLight(DirectLight light, vec3 normal, vec3 viewDir, vec3 objectFragColor, vec3 objectSpecularity)
	{
		// get light direction
		vec3 lightDir = normalize(light.direction);
		// diffuse
		float diff = max(dot(normal, lightDir), 0.0);
		// specular
		vec3 reflectDir = reflect(-lightDir, normal);
		float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);
		// combine results
		vec3 ambient = light.ambient * objectFragColor;
		vec3 diffuse = light.diffuse * diff * objectFragColor;
		vec3 specular = light.specular * spec * objectSpecularity;
		return ((ambient + diffuse + specular) * light.color) * light.intensity;
	}

	vec3 CalcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir, vec3 objectFragColor, vec3 objectSpecularity)
	{	
		// get light direction
		vec3 lightDir = normalize(light.position - fragPos);
		// diffuse
		float diff = max(dot(normal, lightDir), 0.0);
		// specular
		vec3 reflectDir = reflect(-lightDir, normal);
		float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);
		// attenuation
		float distance = length(light.position - fragPos);
		float attenuation = 1.0 / (light.constant + light.linear * distance + light.quadratic * (distance * distance));
		// combine results
		vec3 ambient = light.ambient * objectFragColor;
		vec3 diffuse = light.diffuse * diff * objectFragColor;
		vec3 specular = light.specular * spec * objectSpecularity;
		ambient *= attenuation;
		diffuse *= attenuation;
		specular *= attenuation;
		return ((ambient + diffuse + specular) * light.color) * light.intensity;
	}
);

/* Light Vertex Shader Source Code*/
const GLchar* lightVertexShaderSource = GLSL(440,

	layout(location = 0) in vec3 vecCoords;

	uniform mat4 model;
	uniform mat4 view;
	uniform mat4 projection;

	void main()
	{
		gl_Position = projection * view * model * vec4(vecCoords, 1.0);
	}
);

/* Light Fragment Shader Source Code*/
const GLchar* lightFragmentShaderSource = GLSL(440,

	out vec4 FragColor;

	uniform vec3 color;

	void main()
	{
		FragColor = vec4(color, 1.0f);
	}
);
///////////////////////////////////////////////////////////////////////////////////////


/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
bool UCreateTextures(std::vector<const char*> textureNames, std::vector<GLuint> &textureIDs);
void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods);
void mouseCallback(GLFWwindow* window, double xpos, double ypos);
void scrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void uDrawLegoStud(glm::vec3 position);

// main function
int main(int argc, char* argv[])
{
	if (!UInitialize(argc, argv, &gWindow))
		return EXIT_FAILURE;

	// Create the mesh
	meshes.CreateMeshes();

	// Create the shader program
	if (!UCreateShaderProgram(objectVertexShaderSource, objectFragmentShaderSource, objectShaderProgram))
		return EXIT_FAILURE;
	if (!UCreateShaderProgram(lightVertexShaderSource, lightFragmentShaderSource, lightShaderProgram))
		return EXIT_FAILURE;

	// load textures
	if (!UCreateTextures(textureNames, textureIDs))
	{
		return EXIT_FAILURE;
	}
	
	// set object shader to use texture unit 0
	glUseProgram(objectShaderProgram);
	glUniform1i(glGetUniformLocation(objectShaderProgram, "material.uTexture"), 0);

	// Sets the background color of the window to black (it will be implicitely used by glClear)
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	// render loop
	while (!glfwWindowShouldClose(gWindow))
	{
		// input
		UProcessInput(gWindow);

		// Render this frame
		URender();

		glfwPollEvents();
	}

	// Release mesh data
	meshes.DestroyMeshes();

	// Release shader program
	UDestroyShaderProgram(objectShaderProgram);
	UDestroyShaderProgram(lightShaderProgram);

	exit(EXIT_SUCCESS); // Terminates the program successfully
}

// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
	// GLFW: initialize and configure
	// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// GLFW: window creation
	* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
	if (*window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return false;
	}
	glfwMakeContextCurrent(*window);

	// set callbacks
	glfwSetKeyCallback(gWindow, keyCallback);
	glfwSetCursorPosCallback(*window, mouseCallback);
	glfwSetScrollCallback(*window, scrollCallback);
	glfwSetFramebufferSizeCallback(*window, UResizeWindow);

	// GLFW captures mouse
	glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// GLEW: initialize
	// ----------------
	// Note: if using GLEW version 1.13 or earlier
	glewExperimental = GL_TRUE;
	GLenum GlewInitResult = glewInit();

	if (GLEW_OK != GlewInitResult)
	{
		std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
		return false;
	}

	// Displays GPU OpenGL version
	std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << std::endl;

	return true;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
	// ESC closes window
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	// Camera movement
	float cameraSpeed = 2.5f * deltaTime;
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		camera.ProcessKeyboard(FORWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		camera.ProcessKeyboard(BACKWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		camera.ProcessKeyboard(LEFT, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		camera.ProcessKeyboard(RIGHT, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
		camera.ProcessKeyboard(UP, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
		camera.ProcessKeyboard(DOWN, deltaTime);
}

// adjusts movement speed
void scrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
	camera.ProcessMouseScroll((float)yoffset);
}

// adjusts camera angle
void mouseCallback(GLFWwindow* window, double xpos, double ypos)
{
	// if first time moving mouse
	if (firstMouse)
	{
		lastX = (float)xpos;
		lastY = (float)ypos;
		firstMouse = false;
	}

	// determine how much mouse moved
	float xoffset = (float)xpos - lastX;
	float yoffset = lastY - (float)ypos;

	// save current position for next movement
	lastX = (float)xpos;
	lastY = (float)ypos;

	camera.ProcessMouseMovement(xoffset, yoffset);
}

// KeyCallback used instead of UProcessInput to prevent rapid toggling if key held down too long
void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	// toggles wireframe view
	if (key == GLFW_KEY_SPACE && action == GLFW_PRESS)
	{
		if (isWireframe)
		{
			// Turn off wireframe view
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		}
		else
		{
			// Turn on wireframe view
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		}
		// Swap boolean
		isWireframe = !isWireframe;
	}

	// toggles perspective view
	if (key == GLFW_KEY_P && action == GLFW_PRESS)
	{
		// If switching from orthographic to perspective, restore saved perspective camera settings
		if (isOrtho)
		{
			camera.Position = perspectivePosition;
			camera.Front = perspectiveFront;
			camera.Up = perspectiveUp;
			camera.Yaw = perspectiveYaw;
			camera.Pitch = perspectivePitch;
			std::cout << "Perspective view enabled" << std::endl;
			isOrtho = false;

			// reenable mouse movement and set firstMouse to true to prevent camera jumping if mouse is moved in orthographic mode
			firstMouse = true;
			glfwSetCursorPosCallback(window, mouseCallback);
		}
		projection = glm::perspective(glm::radians(camera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
	}
	
	// toggles ortho view
	if (key == GLFW_KEY_O && action == GLFW_PRESS)
	{
		// if switching from perspective to orthographic, save perspective camera settings
		if (!isOrtho)
		{
			perspectivePosition = camera.Position;
			perspectiveFront = camera.Front;
			perspectiveUp = camera.Up;
			perspectivePitch = camera.Pitch;
			perspectiveYaw = camera.Yaw;
			isOrtho = true;

			// disable mouse movement while in orthographic mode
			glfwSetCursorPosCallback(window, NULL);
		}
		
		// Toggle between 3 different orthographic views (Front, Right, and Top)
		switch (orthoView)
		{
		//Front view
		case 0:
			camera.Position = glm::vec3(0.0f, 0.0f, 10.0f);
			camera.Front = glm::vec3(0.0f, 0.0f, -1.0f);
			camera.Up = glm::vec3(0.0f, 1.0f, 0.0f);
			camera.Yaw = -90.0f;
			camera.Pitch = 0.0f;
			orthoView = 1;
			std::cout << "Front orthographic view enabled" << std::endl;
			break;
		// Right view
		case 1:
			camera.Position = glm::vec3(10.0f, 0.0f, 0.0f);
			camera.Front = glm::vec3(-1.0f, 0.0f, 0.0f);
			camera.Up = glm::vec3(0.0f, 1.0f, 0.0f);
			camera.Yaw = -180.0f;
			camera.Pitch = 0.0f;
			std::cout << "Right orthographic view enabled" << std::endl;
			orthoView = 2;
			break;
		// Top view
		case 2:
			camera.Position = glm::vec3(0.0f, 10.0f, 0.0f);
			camera.Front = glm::vec3(0.0f,-1.0f, 0.0f);
			camera.Up = glm::vec3(0.0f, 0.0f, -1.0f);
			camera.Yaw = -90.0f;
			camera.Pitch = -89.0f;
			std::cout << "Top orthographic view enabled" << std::endl;
			orthoView = 0;
			break;
		default:
			break;
		}
	
		float scale = 160.0f;
		projection = glm::ortho(-WINDOW_WIDTH / scale, WINDOW_WIDTH / scale, -WINDOW_HEIGHT / scale, WINDOW_HEIGHT / scale, 0.1f, 100.0f);
		
	}
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
	glViewport(0, 0, width, height);
}

// Functioned called to render a frame
void URender()
{
	// check timing
	float currentFrame = (float)glfwGetTime();
	deltaTime = currentFrame - lastFrame;
	lastFrame = currentFrame;
	
	glm::mat4 scale;
	glm::mat4 rotation;
	glm::mat4 translation;
	glm::mat4 model;
	GLint modelLoc;
	GLint objectColorLoc;
	GLint viewLoc;
	GLint projLoc;

	// Texture uniform locations
	GLint usesTextureLoc;
	GLint usesSpecularLoc;
	GLint textureCoordsMultipleLoc;

	// Enable z-depth
	glEnable(GL_DEPTH_TEST);

	// Clear the frame and z buffers
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Create view matrix
	view = camera.GetViewMatrix();

	////////////////////////////////////
	// Visualization of light sources //
	////////////////////////////////////
	glUseProgram(lightShaderProgram);  // use light shader
	glUniformMatrix4fv(glGetUniformLocation(lightShaderProgram, "view"), 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(glGetUniformLocation(lightShaderProgram, "projection"), 1, GL_FALSE, glm::value_ptr(projection));
	
	// Light source 1 (Direct light)
	// -----------------------------------------
	glBindVertexArray(meshes.gSphereMesh.vao);  // Activate the VBOs contained within the mesh's VAO
	scale = glm::scale(glm::vec3(0.1f, 0.1f, 0.1f));  // scale
	rotation = glm::rotate(0.0f, glm::vec3(0.0f, 1.0f, 0.0f));  // rotate
	translation = glm::translate(lightPosition1);  // position
	model = translation * rotation * scale;  // create model matrix
	glUniformMatrix4fv(glGetUniformLocation(lightShaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));
	glUniform3fv(glGetUniformLocation(lightShaderProgram, "color"), 1, &lightColor1[0]);  // send color to shader
	glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);  // draw object
	glBindVertexArray(0);  // deactivate VAO

	// Light source 2 (Point light 1)
	// -----------------------------------------
	glBindVertexArray(meshes.gSphereMesh.vao);  // Activate the VBOs contained within the mesh's VAO
	scale = glm::scale(glm::vec3(0.1f, 0.1f, 0.1f));  //scale
	rotation = glm::rotate(0.0f, glm::vec3(0.0f, 1.0f, 0.0f));  // rotate
	translation = glm::translate(lightPosition2);  // position
	model = translation * rotation * scale;  // create model matrix
	glUniformMatrix4fv(glGetUniformLocation(lightShaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));
	glUniform3fv(glGetUniformLocation(lightShaderProgram, "color"), 1, &lightColor2[0]);  // send color to shader
	glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);  // draw object
	glBindVertexArray(0);  // deactivate VAO

	// Light source 3 (Point light 2)
	// -----------------------------------------
	glBindVertexArray(meshes.gSphereMesh.vao);  // Activate the VBOs contained within the mesh's VAO
	scale = glm::scale(glm::vec3(0.1f, 0.1f, 0.1f));  //scale
	rotation = glm::rotate(0.0f, glm::vec3(0.0f, 1.0f, 0.0f));  // rotate
	translation = glm::translate(lightPosition3);  // position
	model = translation * rotation * scale;  // create model matrix
	glUniformMatrix4fv(glGetUniformLocation(lightShaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));
	glUniform3fv(glGetUniformLocation(lightShaderProgram, "color"), 1, &lightColor3[0]);  // send color to shader
	glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);  // draw object
	glBindVertexArray(0);  // deactivate VAO

	/////////////////////////////
	// Render objects in scene //
	/////////////////////////////
	glUseProgram(objectShaderProgram);  // use object shader

	// find uniform locations in shader
	modelLoc = glGetUniformLocation(objectShaderProgram, "model");
	usesTextureLoc = glGetUniformLocation(objectShaderProgram, "material.usesTexture");
	usesSpecularLoc = glGetUniformLocation(objectShaderProgram, "material.usesSpecular");
	textureCoordsMultipleLoc = glGetUniformLocation(objectShaderProgram, "textureCoordsMultiple");
	objectColorLoc = glGetUniformLocation(objectShaderProgram, "material.color");

	// pass global information to object shaders
	glUniformMatrix4fv(glGetUniformLocation(objectShaderProgram, "view"), 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(glGetUniformLocation(objectShaderProgram, "projection"), 1, GL_FALSE, glm::value_ptr(projection));
	glUniform3fv(glGetUniformLocation(objectShaderProgram, "viewPosition"), 1, &camera.Position[0]);
	glUniform1i(glGetUniformLocation(objectShaderProgram, "material.uTexture"), 0);  // object use texture unit 0 for diffuse maps which is updated for each object
	glUniform1i(glGetUniformLocation(objectShaderProgram, "material.uSpecular"), 1);  // object use texture unit 1 for specular maps which is updated for each object

	glUniform3fv(glGetUniformLocation(objectShaderProgram, "directLight.direction"), 1, &lightPosition1[0]);  // direct light data
	glUniform3f(glGetUniformLocation(objectShaderProgram, "directLight.ambient"), 0.05f, 0.05f, 0.05f);
	glUniform3f(glGetUniformLocation(objectShaderProgram, "directLight.diffuse"), 0.8f, 0.8f, 0.8f);
	glUniform3f(glGetUniformLocation(objectShaderProgram, "directLight.specular"), 1.0f, 1.0f, 1.0f);
	glUniform1f(glGetUniformLocation(objectShaderProgram, "directLight.intensity"), 0.6f);
	glUniform3fv(glGetUniformLocation(objectShaderProgram, "directLight.color"), 1, &lightColor1[0]);

	glUniform3fv(glGetUniformLocation(objectShaderProgram, "pointLight1.position"), 1, &lightPosition2[0]);  // point light 1 data
	glUniform1f(glGetUniformLocation(objectShaderProgram, "pointLight1.constant"), 1.0f);
	glUniform1f(glGetUniformLocation(objectShaderProgram, "pointLight1.linear"), 0.01f);
	glUniform1f(glGetUniformLocation(objectShaderProgram, "pointLight1.quadratic"), 0.0064f);
	glUniform3f(glGetUniformLocation(objectShaderProgram, "pointLight1.ambient"), 0.05f, 0.05f, 0.05f);
	glUniform3f(glGetUniformLocation(objectShaderProgram, "pointLight1.diffuse"), 0.8f, 0.8f, 0.8f);
	glUniform3f(glGetUniformLocation(objectShaderProgram, "pointLight1.specular"), 1.0f, 1.0f, 1.0f);
	glUniform1f(glGetUniformLocation(objectShaderProgram, "pointLight1.intensity"), 1.0f);
	glUniform3fv(glGetUniformLocation(objectShaderProgram, "pointLight1.color"), 1, &lightColor2[0]);

	glUniform3fv(glGetUniformLocation(objectShaderProgram, "pointLight2.position"), 1, &lightPosition3[0]);  // point light 2 data
	glUniform1f(glGetUniformLocation(objectShaderProgram, "pointLight2.constant"), 1.0f);
	glUniform1f(glGetUniformLocation(objectShaderProgram, "pointLight2.linear"), 0.01f);
	glUniform1f(glGetUniformLocation(objectShaderProgram, "pointLight2.quadratic"), 0.0064f);
	glUniform3f(glGetUniformLocation(objectShaderProgram, "pointLight2.ambient"), 0.05f, 0.05f, 0.05f);
	glUniform3f(glGetUniformLocation(objectShaderProgram, "pointLight2.diffuse"), 0.8f, 0.8f, 0.8f);
	glUniform3f(glGetUniformLocation(objectShaderProgram, "pointLight2.specular"), 1.0f, 1.0f, 1.0f);
	glUniform1f(glGetUniformLocation(objectShaderProgram, "pointLight2.intensity"), 1.0f);
	glUniform3fv(glGetUniformLocation(objectShaderProgram, "pointLight2.color"), 1, &lightColor3[0]);

	// Plane object
	// ------------
	glBindVertexArray(meshes.gPlaneMesh.vao);  // Activate the VBOs contained within the mesh's VAO
	scale = glm::scale(glm::vec3(6.0f, 1.0f, 6.0f));  // scale
	rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));  // rotate
	translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));  // position
	model = translation * rotation * scale;  // create model matrix
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glProgramUniform1i(objectShaderProgram, usesTextureLoc, 1);  // mesh uses a texture
	glProgramUniform1i(objectShaderProgram, textureCoordsMultipleLoc, 3);  // texture is tiled 3x3
	glProgramUniform1i(objectShaderProgram, usesSpecularLoc, 1);  // mesh uses a specular map
	glUniform1f(glGetUniformLocation(objectShaderProgram, "material.shininess"), 128.0f);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, textureIDs[3]);  // bind texture
	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, textureIDs[12]);  // bind specular map
	glDrawElements(GL_TRIANGLES, meshes.gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);  // draw object
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, 0);  // unbind texture
	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, 0);  // unbind specular map
	glBindVertexArray(0);  // deactivate VAO

	// Large Lego object (complex object of cube and 8 cylinders)
	// -----------------
	// Lego base (stretched cube)
	// --------------------------
	glBindVertexArray(meshes.gBoxMesh.vao);  // Activate the VBOs contained within the mesh's VAO
	scale = glm::scale(glm::vec3(4.4f, 0.2f, 2.2f));  // scale
	rotation = glm::rotate(0.9f, glm::vec3(0.0, 1.0f, 0.0f));  // rotate
	translation = glm::translate(glm::vec3(-1.8f, 0.1f, -1.0f));  // position
	model = translation * rotation * scale;  // create model matrix
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glProgramUniform1i(objectShaderProgram, usesTextureLoc, 1);  // mesh uses a texture
	glProgramUniform1i(objectShaderProgram, textureCoordsMultipleLoc, 1);
	glProgramUniform1i(objectShaderProgram, usesSpecularLoc, 0);  // mesh doesn't use a specular map
	glUniform1f(glGetUniformLocation(objectShaderProgram, "material.shininess"), 16.0f);
	glActiveTexture(GL_TEXTURE0);
	// Draw individual sides and assign specific texture to them. Bottom not drawn to prevent odd visual effects under plane
	glBindTexture(GL_TEXTURE_2D, textureIDs[6]);  // back
	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, (void*)(0 * sizeof(GL_UNSIGNED_INT)));
	glBindTexture(GL_TEXTURE_2D, textureIDs[7]);  // left
	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, (void*)(12 * sizeof(GL_UNSIGNED_INT)));
	glBindTexture(GL_TEXTURE_2D, textureIDs[8]);  // right
	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, (void*)(18 * sizeof(GL_UNSIGNED_INT)));
	glBindTexture(GL_TEXTURE_2D, textureIDs[4]);  // top
	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, (void*)(24 * sizeof(GL_UNSIGNED_INT)));
	glBindTexture(GL_TEXTURE_2D, textureIDs[5]);  // front
	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, (void*)(30 * sizeof(GL_UNSIGNED_INT)));
	glBindTexture(GL_TEXTURE_2D, 0);  // unbind texture
	glBindVertexArray(0);  // deactivate VAO

	// Lego studs (cylinders)
	// ----------------------
	uDrawLegoStud(glm::vec3(-3.2f, 0.2f, 0.0f));   // Lego stud 1
	uDrawLegoStud(glm::vec3(-2.6f, 0.2f, -0.8f));   // Lego stud 2
	uDrawLegoStud(glm::vec3(-2.0f, 0.2f, -1.6f));  // Lego stud 3
	uDrawLegoStud(glm::vec3(-1.2f, 0.2f, -2.5f));  // Lego stud 4
	uDrawLegoStud(glm::vec3(-2.4f, 0.2f, 0.7f));   // Lego stud 5
	uDrawLegoStud(glm::vec3(-1.8f, 0.2f, -0.1f));   // Lego stud 6
	uDrawLegoStud(glm::vec3(-1.1f, 0.2f, -0.9f));   // Lego stud 7
	uDrawLegoStud(glm::vec3(-0.4f, 0.2f, -1.8f));  // Lego stud 8

	// Salt Container (cylinder)
	// ----------------------
	glBindVertexArray(meshes.gCylinderMesh.vao);  // Activate the VBOs contained within the mesh's VAO
	scale = glm::scale(glm::vec3(0.6f, 1.8f, 0.6f));  // scale
	rotation = glm::rotate(1.25f, glm::vec3(0.0f, 1.0f, 0.0f));  // rotate
	translation = glm::translate(glm::vec3(1.4f, 0.0f, -0.4f));  // position
	model = translation * rotation * scale;  // create model matrix
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glProgramUniform1i(objectShaderProgram, usesTextureLoc, 1);  // mesh uses a texture
	glProgramUniform1i(objectShaderProgram, textureCoordsMultipleLoc, 1);
	glProgramUniform1i(objectShaderProgram, usesSpecularLoc, 0);  // mesh doesn't use a specular map
	glActiveTexture(GL_TEXTURE0);
	// Draw individual sides and assign specific texture to them. Bottom not drawn becuase it's not seen
	glUniform1f(glGetUniformLocation(objectShaderProgram, "material.shininess"), 16.0f);  // sides are glossy paper so have more shininess than top
	glBindTexture(GL_TEXTURE_2D, textureIDs[11]);
	glUniform1f(glGetUniformLocation(objectShaderProgram, "material.shininess"), 8.0f);  // matte paper
	glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides
	glBindTexture(GL_TEXTURE_2D, 0);  // unbind texture
	// Switch back to using a color
	glProgramUniform1i(objectShaderProgram, usesTextureLoc, 0);  // stop using a texture
	glProgramUniform3f(objectShaderProgram, objectColorLoc, 1.0f, 1.0f, 1.0f);  // send color
	glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
	glBindVertexArray(0);  // deactivate VAO

	// Triangular Rubix's Cube (3 sided pyramid)
	// -----------------------------------------
	glBindVertexArray(meshes.gPyramid3Mesh.vao);  // Activate the VBOs contained within the mesh's VAO
	scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));  // scale
	rotation = glm::rotate(-3.0f, glm::vec3(0.0f, 1.0f, 0.0f));  // rotate
	translation = glm::translate(glm::vec3(-1.0f, 0.5f, 2.0f));  // postion
	model = translation * rotation * scale;  // create model matrix
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glProgramUniform1i(objectShaderProgram, usesTextureLoc, 1);  // mesh uses a texture
	glProgramUniform1i(objectShaderProgram, textureCoordsMultipleLoc, 1);
	glProgramUniform1i(objectShaderProgram, usesSpecularLoc, 1);  // mesh uses a specular map
	glUniform1f(glGetUniformLocation(objectShaderProgram, "material.shininess"), 32.0f);
	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, textureIDs[14]);  // bind specular map
	glActiveTexture(GL_TEXTURE0);
	// Draw individual sides and assign specific texture to them. Bottom not drawn to prevent odd visual effects under plane
	glBindTexture(GL_TEXTURE_2D, textureIDs[0]);  // side 1
	glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
	glBindTexture(GL_TEXTURE_2D, textureIDs[1]);  // side 2
	glDrawArrays(GL_TRIANGLE_STRIP, 4, 4);
	glBindTexture(GL_TEXTURE_2D, textureIDs[2]);  // side 3
	glDrawArrays(GL_TRIANGLE_STRIP, 8, 4);
	glBindTexture(GL_TEXTURE_2D, 0);  // unbind texture
	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, 0);  // unbind specular map
	glBindVertexArray(0);  // deactivate VAO

	// Watermelon toy (Sphere)
	// -----------------------------------------
	glBindVertexArray(meshes.gSphereMesh.vao);  // Activate the VBOs contained within the mesh's VAO
	scale = glm::scale(glm::vec3(0.7f, 0.7f, 0.7f));  // scale
	rotation = glm::rotate(0.0f, glm::vec3(0.0f, 1.0f, 0.0f));  // rotate
	translation = glm::translate(glm::vec3(0.5f, 0.0f, 1.6f));  // position
	model = translation * rotation * scale;  // create model matrix
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glProgramUniform1i(objectShaderProgram, usesTextureLoc, 1);  // mesh uses a texture
	glProgramUniform1i(objectShaderProgram, textureCoordsMultipleLoc, 1);
	glProgramUniform1i(objectShaderProgram, usesSpecularLoc, 0);  // mesh doesn't use a specular map
	glUniform1f(glGetUniformLocation(objectShaderProgram, "material.shininess"), 16.0f);  // made of painted foam. Slightly shiny but less so than plastic
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, textureIDs[10]);
	glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices / 2, GL_UNSIGNED_INT, (void*)0);  // draws top half of sphere
	glBindTexture(GL_TEXTURE_2D, 0);  // unbind texture
	glBindVertexArray(0);  // deactivate VAO

	// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
	glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}

// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
	// Compilation and linkage error reporting
	int success = 0;
	char infoLog[512];

	// Create a Shader program object.
	programId = glCreateProgram();

	// Create the vertex and fragment shader objects
	GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
	GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

	// Retrive the shader source
	glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
	glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

	// Compile the vertex shader, and print compilation errors (if any)
	glCompileShader(vertexShaderId); // compile the vertex shader
	// check for shader compile errors
	glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

		return false;
	}

	glCompileShader(fragmentShaderId); // compile the fragment shader
	// check for shader compile errors
	glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
		std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

		return false;
	}

	// Attached compiled shaders to the shader program
	glAttachShader(programId, vertexShaderId);
	glAttachShader(programId, fragmentShaderId);

	glLinkProgram(programId);   // links the shader program
	// check for linking errors
	glGetProgramiv(programId, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
		std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

		return false;
	}

	glUseProgram(programId);    // Uses the shader program

	return true;
}

// Cleans up shader program
void UDestroyShaderProgram(GLuint programId)
{
	glDeleteProgram(programId);
}

// cycle through texture name and texture ID vectors. Generate and assign each texture to ID
bool UCreateTextures(std::vector<const char*> textureNames, std::vector<GLuint> &textureIDs)
{
	int width, height, channels;
	for (int i = 0; i < textureNames.size(); i++)
	{
		stbi_set_flip_vertically_on_load(true);
		unsigned char* sourceImage = stbi_load(textureNames[i], &width, &height, &channels, 0);
		if (sourceImage)
		{
			glGenTextures(1, &textureIDs[i]);
			glBindTexture(GL_TEXTURE_2D, textureIDs[i]);

			// texture wrapping
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

			// texture filtering
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

			if (channels == 3)
			{
				glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, sourceImage);
			}
			else if (channels == 4)
			{
				glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, sourceImage);
			}
			else
			{
				std::cout << "Cannot handle images with " << channels << " channel(s)" << std::endl;
				return false;
			}

			glGenerateMipmap(GL_TEXTURE_2D);

			// free up image memory and unbind texture
			stbi_image_free(sourceImage);
			glBindTexture(GL_TEXTURE_2D, 0);
		}
		else
		{
			std::cout << "Failed to load texture " << textureNames[i] << std::endl;
			return false;
		}
	}
	return true;
}

// Draws Lego stud based on position
void uDrawLegoStud(glm::vec3 position)
{
	glBindVertexArray(meshes.gCylinderMesh.vao);  // Activate the VBOs contained within the mesh's VAO
	glm::mat4 scale = glm::scale(glm::vec3(0.35f, 0.2f, 0.35f));  // scale
	glm::mat4 rotation = glm::rotate(0.9f, glm::vec3(0.0f, 1.0f, 0.0f));  // rotate
	glm::mat4 translation = glm::translate(position);  // position
	glm::mat4 model = translation * rotation * scale;  // create model matrix
	glUniformMatrix4fv(glGetUniformLocation(objectShaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));
	glProgramUniform1i(objectShaderProgram, glGetUniformLocation(objectShaderProgram, "material.usesTexture"), 1);  // mesh uses a texture
	glProgramUniform1i(objectShaderProgram, glGetUniformLocation(objectShaderProgram, "textureCoordsMultiple"), 1);
	glProgramUniform1i(objectShaderProgram, glGetUniformLocation(objectShaderProgram, "material.usesSpecular"), 0);  // mesh doesn't use a specular map
	glUniform1f(glGetUniformLocation(objectShaderProgram, "material.shininess"), 16.0f);
	glActiveTexture(GL_TEXTURE0);
	// Draw individual sides and assign specific texture to them. Bottom not drawn becuase it's not seen
	glBindTexture(GL_TEXTURE_2D, textureIDs[9]);
	glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
	glBindTexture(GL_TEXTURE_2D, textureIDs[13]);
	glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides
	glBindTexture(GL_TEXTURE_2D, 0);  // unbind texture
	glBindVertexArray(0);  // deactivate VAO
}